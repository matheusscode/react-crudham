function generateRandomData() {
  const firstNames = [
    "Alice",
    "Bob",
    "Charlie",
    "Diana",
    "Eva",
    "Frank",
    "Grace",
    "Henry",
    "Ivy",
    "Jack",
  ];
  const lastNames = [
    "Smith",
    "Johnson",
    "Williams",
    "Jones",
    "Brown",
    "Davis",
    "Miller",
    "Wilson",
    "Taylor",
  ];
  const jobTitles = ["Developer", "Designer", "Engineer", "Manager", "Analyst"];
  const statuses = ["Active", "Inactive", "Pending", "Blocked"];

  const getRandomElement = (arr) => arr[Math.floor(Math.random() * arr.length)];

  const randomFirstName = getRandomElement(firstNames);
  const randomLastName = getRandomElement(lastNames);
  const randomAge = Math.floor(Math.random() * 30) + 20; // Random age between 20 and 49
  const randomJobTitle = getRandomElement(jobTitles);
  const randomStatus = getRandomElement(statuses);

  return {
    firstName: randomFirstName,
    lastName: randomLastName,
    age: randomAge,
    jobTitle: randomJobTitle,
    status: randomStatus,
  };
}

function generateNumberQuery() {
  let query = "";
  for (let i = 1; i <= 1000; i++) {
    if (i > 1) {
      query += " union ";
    }
    const randomData = generateRandomData();
    query += `SELECT ${i} as id, '${randomData.firstName}' as firstName, '${randomData.lastName}' as lastName, ${randomData.age} as idade, '${randomData.jobTitle}' as office, '${randomData.status}' as status FROM dual`;
  }
  return query;
}

const dataUsers = generateNumberQuery();
module.exports = dataUsers;
