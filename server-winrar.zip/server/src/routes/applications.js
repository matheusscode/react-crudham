const express = require("express");
const router = express.Router();
const aplicationsController = require("../controllers/applications");
const introductionController = require("../controllers/introduction");

router.get("/api", introductionController.introduction);
router.get("/applications", aplicationsController.getApplications);
router.get("/applications/:id", aplicationsController.getApplicationById);
router.post("/add-application", aplicationsController.addApplication);
router.delete(
  "/delete-application/:id",
  aplicationsController.deleteApplication
);
router.put("/edit-application", aplicationsController.editApplication);

module.exports = router;
