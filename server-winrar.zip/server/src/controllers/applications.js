const execute = require("../config/dbconnection").execute;

exports.getApplications = async function (req, res) {
  sql = "SELECT * FROM DBAADV.TB_APLICACAO_HAM order by 1 asc";
  result = await execute(sql);
  res.send(result.rows);
};

exports.editApplication = async function (req, res) {
  console.log("UPDATE TABLE");
  console.log(req.body);

  let applicationCode = req.body.CD_APLICACAO;
  let applicationName = req.body.NM_APLICACAO;
  let applicationDescription = req.body.DS_APLICACAO;
  let responsibleName = req.body.NM_RESPONSAVEL;
  let technologyName = req.body.DS_TECNOLOGIAS;
  let accessLink = req.body.DS_LINK_ACESSO;

  try {
    const sql = `UPDATE TB_APLICACAO_HAM SET
      NM_APLICACAO = '${applicationName}',
      DS_APLICACAO = '${applicationDescription}',
      NM_RESPONSAVEL = '${responsibleName}',
      DS_TECNOLOGIAS = '${technologyName}',
      DS_LINK_ACESSO = '${accessLink}',
      DT_ATUALIZACAO = sysdate
      WHERE CD_APLICACAO = ${applicationCode}`;

    console.log(sql);
    result = await execute(sql);
    res.send(result.rows);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};

exports.getApplicationById = async function (req, res) {
  let { id } = req.params;

  try {
    const sql = `SELECT * FROM TB_APLICACAO_HAM WHERE CD_APLICACAO = ${id}`;
    console.log(sql);
    const result = await execute(sql);

    if (result.rows.length === 0) {
      return res.status(404).json({ error: "Application not found." });
    }

    res.send(result.rows[0]);
  } catch (error) {
    console.error("Error fetching application:", error);
    res.status(500).json({ error: "Error fetching application." });
  }
};

exports.deleteApplication = async function (req, res) {
  let { id } = req.params;

  try {
    const sql = `DELETE FROM TB_APLICACAO_HAM WHERE CD_APLICACAO = ${id}`;
    console.log(sql);
    result = await execute(sql);
    res.send(result.rows);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};

exports.addApplication = async function (req, res) {
  console.log("TABLE TEST");
  console.log(req.body);

  let applicationName = req.body.NM_APLICACAO;
  let applicationDescription = req.body.DS_APLICACAO;
  let responsibleName = req.body.NM_RESPONSAVEL;
  let technologyName = req.body.DS_TECNOLOGIAS;
  let accessLink = req.body.DS_LINK_ACESSO;

  try {
    const sql = `INSERT into TB_APLICACAO_HAM (
        NM_APLICACAO,
        DS_APLICACAO,
        NM_RESPONSAVEL,
        DS_TECNOLOGIAS,
        DS_LINK_ACESSO,
        DT_CRIACAO,
        DT_ATUALIZACAO
      ) values (
        '${applicationName}', 
        '${applicationDescription}', 
        '${responsibleName}', 
        '${technologyName}',
        '${accessLink}',
        sysdate,
        sysdate
        )
      `;
    console.log(sql);
    result = await execute(sql);
    res.send(result.rows);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};
