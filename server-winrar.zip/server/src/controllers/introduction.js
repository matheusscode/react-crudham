exports.introduction = function (req, res) {
  const routes = {
    firstRoute: "localhost:3030/primeiraRota",
    secondaryRoute: "localhost:3030/segundaRota",
  };

  const routeStatus = {
    firstRoute: "online",
    secondaryRoute: "offline",
  };

  res.json({
    routes,
    routeStatus,
  });
};
