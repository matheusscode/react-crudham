const express = require("express");
const app = express();
const methodOverride = require("method-override");
const cors = require("cors");
const path = require("path");
const applicationRouter = require(path.resolve("./src/routes/applications"));

require("dotenv").config();
require("./src/config/dbconnection").init();

var corsOptions = {
  origin: "*",
  optionsSuccessStatus: 200,
};

// Configura estratégia de autenticação
app.use(cors(corsOptions));

app.use(function (req, res, next) {
  res.setHeader("Access-Control-Allow-Origin", "*");
  res.setHeader("Access-Control-Allow-Methods", "GET,PUT,POST,DELETE");
  res.setHeader("Access-Control-Allow-Headers", "Content-Type");
  next();
});

app.use(
  express.urlencoded({
    extended: true,
  })
); // interpreta a códificação dos dados que vem via POST
app.use(express.json()); // pega todos os arquivos e os converte em JSON
app.use(methodOverride());

app.use("/", applicationRouter);

app.listen(process.env.PORT, () => {
  console.log(`API rodando: [port ${process.env.PORT}]`);
});
